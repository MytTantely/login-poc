import React from 'react'
import {
  Route,
  Switch
} from 'react-router-dom'
import HomePage from './pages/HomePage'
import AboutPage from './pages/AboutPage'
import ArticlePage from './pages/ArticlePage'
import ArticlesListPage from './pages/ArticlesListPage'
import NavBar from './NavBar'
import NotFoundPage from './pages/NotFoundPage'
import { ProtectedRoute } from './lib/protected.route'


import './App.css'

function App() {
  return (
      <div className="App">
        <NavBar />
        <div id="page-body">
          <Switch>
            <Route path="/" component={HomePage} exact />
            <ProtectedRoute path="/about" component={AboutPage} />
            <ProtectedRoute path="/articles" component={ArticlesListPage} />
            <ProtectedRoute path="/article/:name" component={ArticlePage} />
            <ProtectedRoute component={NotFoundPage} />
          </Switch>
        </div>
      </div>
  );
}

export default App;
