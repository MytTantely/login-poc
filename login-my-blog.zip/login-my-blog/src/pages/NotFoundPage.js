import React from 'react'

const NotFoundPage = () => (
    <h1>404: Not found page</h1>
)

export default NotFoundPage